# ProGuard rules for Smart Voice Assistant

# Keep MediaPipe classes
-keep class com.google.mediapipe.** { *; }
-dontwarn com.google.mediapipe.**

# Keep Room entities
-keep class com.smartvoice.assistant.data.local.** { *; }

# Keep model classes
-keep class com.smartvoice.assistant.data.model.** { *; }

# General Android rules
-keepattributes Signature
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable
